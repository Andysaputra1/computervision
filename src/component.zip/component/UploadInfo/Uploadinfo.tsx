import React from 'react';
import { Upload, Trash2, Search, Loader2, CheckCircle, Leaf, MapPin, AlertCircle, Info, Bookmark } from 'lucide-react';
import './UploadInfo.css';

interface UploadInfoProps {
  image: string | null;
  loading: boolean;
  status: string;
  prediction: any;
  mushroomInfo: any;
  isSaved: boolean;
  onImageUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onAnalyze: () => void;
  onSave: () => void;
  onReset: () => void;
}

export default function UploadInfo({ 
  image, loading, status, prediction, mushroomInfo, isSaved, 
  onImageUpload, onAnalyze, onSave, onReset 
}: UploadInfoProps) {
  return (
    <section className="scanner-section">
      <div className="scanner-container">
        <div className="scanner-header">
          <span className="text-green-600 font-bold tracking-wider text-xs uppercase mb-2 block">Scanner</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-stone-900">Identifikasi Spesimen</h2>
        </div>

        <div className="scanner-layout">
          {/* Left: Upload Area */}
          <div className="space-y-6">
            <div className={`upload-box ${image ? 'has-image' : ''}`}>
              {!image ? (
                <label className="cursor-pointer block">
                  <div className="w-16 h-16 bg-white rounded-full shadow-sm flex items-center justify-center mx-auto mb-4 hover:scale-110 transition-transform">
                    <Upload className="text-green-600" size={28} />
                  </div>
                  <h3 className="text-lg font-bold text-stone-800 mb-1">Upload Foto Jamur</h3>
                  <p className="text-stone-500 text-sm mb-6">Drag & drop atau klik untuk memilih</p>
                  <span className="inline-block bg-stone-900 text-white px-4 py-2 rounded-lg text-sm font-bold">Pilih File</span>
                  <input type="file" accept="image/*" className="hidden" onChange={onImageUpload} />
                </label>
              ) : (
                <div className="relative group">
                  <img src={image} alt="Preview" className="image-preview" />
                  {!loading && (
                    <button onClick={onReset} className="reset-btn">
                      <Trash2 size={18} />
                    </button>
                  )}
                </div>
              )}
            </div>

            {image && !loading && status !== 'complete' && (
              <button
                onClick={onAnalyze}
                className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-700 shadow-lg shadow-green-200 transition-all flex items-center justify-center gap-2"
              >
                <Search size={20} /> Analisa Sekarang
              </button>
            )}

            {loading && (
              <div className="status-card">
                <div className="status-step">
                  <div className={`icon-circle ${status === 'analyzing_image' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
                    {status === 'analyzing_image' ? <Loader2 className="animate-spin" /> : <CheckCircle />}
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-800">Visual Analysis</h4>
                    <p className="text-xs text-stone-500">Computer Vision sedang bekerja...</p>
                  </div>
                </div>
                <div className="w-0.5 h-4 bg-stone-200 ml-5 mb-2"></div>
                <div className="status-step mb-0">
                  <div className={`icon-circle ${status === 'fetching_info' ? 'bg-purple-100 text-purple-600' : (status === 'complete' ? 'bg-green-100 text-green-600' : 'bg-stone-100 text-stone-300')}`}>
                    {status === 'fetching_info' ? <Loader2 className="animate-spin" /> : (status === 'complete' ? <CheckCircle /> : <div className="w-6 h-6" />)}
                  </div>
                  <div>
                    <h4 className={`font-bold ${status === 'fetching_info' ? 'text-stone-800' : 'text-stone-400'}`}>Botanical Data</h4>
                    <p className="text-xs text-stone-400">Gemini AI mencari fakta...</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-1">
            {prediction && mushroomInfo ? (
              <div className="result-card">
                <div className="result-header">
                  <div className="absolute top-0 right-0 p-8 opacity-10"><Leaf size={120} /></div>
                  <div className="relative z-10">
                    <span className="inline-block bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold mb-3 border border-white/10">
                      Confidence: {(prediction.confidence * 100).toFixed(0)}%
                    </span>
                    <h2 className="text-3xl font-bold mb-1">{prediction.name}</h2>
                    <p className="text-stone-300 text-sm">Identifikasi selesai</p>
                  </div>
                </div>

                <div className="result-body space-y-6">
                  <p className="text-lg text-stone-700 leading-relaxed">{mushroomInfo.description}</p>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-stone-50 rounded-2xl border border-stone-100">
                      <div className="flex items-center gap-2 text-stone-500 text-xs font-bold uppercase mb-2">
                        <MapPin size={14} /> Region
                      </div>
                      <p className="font-semibold text-stone-800">{mushroomInfo.region}</p>
                    </div>
                    <div className={`p-4 rounded-2xl border ${mushroomInfo.edibility.toLowerCase().includes('beracun') ? 'bg-red-50 border-red-100 text-red-800' : 'bg-green-50 border-green-100 text-green-800'}`}>
                      <div className="flex items-center gap-2 text-xs font-bold uppercase mb-2 opacity-70">
                        <AlertCircle size={14} /> Safety
                      </div>
                      <p className="font-semibold">{mushroomInfo.edibility}</p>
                    </div>
                  </div>

                  <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-100">
                    <h4 className="text-blue-800 font-bold text-sm mb-1 flex items-center gap-2"><Info size={16} /> Fakta Unik</h4>
                    <p className="text-blue-700 text-sm italic">"{mushroomInfo.fun_fact}"</p>
                  </div>

                  <div className="pt-4 border-t border-stone-100 flex justify-end">
                    <button
                      onClick={onSave}
                      disabled={isSaved}
                      className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${isSaved ? 'bg-stone-100 text-stone-400 cursor-default' : 'bg-stone-900 text-white hover:bg-black hover:scale-105 shadow-lg'}`}
                    >
                      {isSaved ? <><CheckCircle size={18} /> Tersimpan</> : <><Bookmark size={18} /> Simpan ke Koleksi</>}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-stone-200 rounded-3xl bg-stone-50/50">
                <div className="w-20 h-20 bg-stone-100 rounded-full flex items-center justify-center mb-4 text-stone-300">
                  <Search size={40} />
                </div>
                <h3 className="text-xl font-bold text-stone-400 mb-2">Menunggu Data</h3>
                <p className="text-stone-400 max-w-xs mx-auto">Upload foto di panel sebelah kiri untuk melihat hasil identifikasi detil disini.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}