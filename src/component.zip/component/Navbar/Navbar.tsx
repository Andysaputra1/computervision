import React, { useState } from 'react';
import { Leaf, User, LogOut, ChevronDown } from 'lucide-react';
import './Navbar.css';

interface NavbarProps {
  user: any;
  onLogout: () => void;
  onOpenAuth: () => void;
  refs: {
    homeRef: React.RefObject<HTMLDivElement>;
    scannerRef: React.RefObject<HTMLDivElement>;
    collectionRef: React.RefObject<HTMLDivElement>;
  };
}

export default function Navbar({ user, onLogout, onOpenAuth, refs }: NavbarProps) {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const { homeRef, scannerRef, collectionRef } = refs;

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth' });
    setShowUserMenu(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        {/* Logo */}
        <div className="navbar-logo" onClick={() => scrollToSection(homeRef)}>
          <div className="logo-icon">
            <Leaf size={20} fill="currentColor" />
          </div>
          <h1 className="logo-text">Mushroom<span style={{ color: '#16a34a' }}>Vision</span></h1>
        </div>

        {/* Desktop Links */}
        <div className="nav-links">
          <button onClick={() => scrollToSection(homeRef)} className="nav-item">Home</button>
          <button onClick={() => scrollToSection(scannerRef)} className="nav-item">Scanner</button>
          <button onClick={() => scrollToSection(collectionRef)} className="nav-item">Koleksi</button>
        </div>

        {/* User Icon / Auth */}
        <div className="relative">
          {user ? (
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="user-menu-btn"
            >
              <div className="user-avatar">
                {user.email[0].toUpperCase()}
              </div>
              <ChevronDown size={14} className={`transition-transform text-stone-500 ${showUserMenu ? 'rotate-180' : ''}`} />
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              className="login-btn"
              title="Login"
            >
              <User size={20} />
            </button>
          )}

          {/* Dropdown Menu */}
          {showUserMenu && user && (
            <div className="dropdown-menu">
              <div className="px-4 py-3 border-b border-stone-50">
                <p className="text-xs font-bold text-stone-400 uppercase">Signed in as</p>
                <p className="text-sm font-semibold text-stone-800 truncate">{user.email}</p>
              </div>
              <button 
                onClick={() => { onLogout(); setShowUserMenu(false); }} 
                className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
              >
                <LogOut size={14} /> Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}