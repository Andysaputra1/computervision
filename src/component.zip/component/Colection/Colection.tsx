import React from 'react';
import { Lock, User, Trash2 } from 'lucide-react';
import './Colection.css';

interface ColectionProps {
  user: any;
  collection: any[];
  onDelete: (id: number) => void;
  onLoginRequest: () => void;
}

export default function Colection({ user, collection, onDelete, onLoginRequest }: ColectionProps) {
  return (
    <section className="collection-section">
      <div className="collection-header">
        <div>
          <span className="text-green-600 font-bold tracking-wider text-xs uppercase mb-2 block">Library</span>
          <h2 className="text-3xl font-bold text-stone-900">Buku Koleksi</h2>
        </div>
        {user && (
          <div className="count-badge">
            {collection.length} Spesimen Tersimpan
          </div>
        )}
      </div>

      {!user ? (
        // LOCKED STATE
        <div className="locked-box">
          <div className="absolute top-0 left-0 w-full h-full opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
          <div className="relative z-10 max-w-xl mx-auto">
            <div className="locked-icon-bg">
              <Lock size={32} className="text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Koleksi Terkunci</h3>
            <p className="text-stone-300 mb-8 text-lg">Buat akun gratis untuk menyimpan setiap jamur yang kamu temukan secara permanen di cloud.</p>
            <button onClick={onLoginRequest} className="login-action-btn">
              <User size={18} /> Login / Register
            </button>
          </div>
        </div>
      ) : collection.length === 0 ? (
        // EMPTY STATE
        <div className="border border-stone-200 bg-white rounded-3xl p-16 text-center">
          <p className="text-stone-500 mb-6">Belum ada koleksi. Ayo mulai berburu jamur!</p>
        </div>
      ) : (
        // GRID LIST
        <div className="collection-grid">
          {collection.map((item) => (
            <div key={item.id} className="collection-card group">
              <div className="card-image-container">
                <img src={item.image} alt={item.name} className="card-image" />
                <div className="card-overlay">
                  <span className="text-white text-xs font-mono">{item.dateAdded}</span>
                </div>
              </div>
              <div className="card-content">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-lg text-stone-900 line-clamp-1">{item.name}</h4>
                  <button
                    onClick={() => onDelete(item.id)}
                    className="text-stone-300 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
                <p className="text-sm text-stone-500 line-clamp-2 mb-4 h-10">{item.info.description}</p>
                <div className="flex gap-2">
                  <span className="px-2 py-1 bg-stone-100 rounded text-xs font-bold text-stone-600">{item.info.region}</span>
                  <span className={`px-2 py-1 rounded text-xs font-bold ${item.info.edibility.toLowerCase().includes('beracun') ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                    {item.info.edibility}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}