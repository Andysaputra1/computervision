import React from 'react';
import { Camera, Book, Search, Info, MapPin } from 'lucide-react';
import './Hero.css';

interface HeroProps {
  onStartScan: () => void;
  onViewCollection: () => void;
}

export default function Hero({ onStartScan, onViewCollection }: HeroProps) {
  return (
    <section className="hero-section">
      {/* Decorative Blobs */}
      <div className="blob blob-green"></div>
      <div className="blob blob-amber"></div>

      <div className="hero-content">
        <div className="badge-pill">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
          </span>
          AI-Powered Mushroom Identification
        </div>

        <h1 className="hero-title">
          Temukan Keajaiban <br /> <span className="gradient-text">Dunia Fungi</span>
        </h1>

        <p className="hero-desc">
          Unggah foto jamur, identifikasi spesiesnya secara instan dengan AI, dan bangun ensiklopedia jamur pribadimu di cloud.
        </p>

        <div className="hero-buttons">
          <button
            onClick={onStartScan}
            className="w-full sm:w-auto bg-stone-900 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-black hover:scale-105 transition-all shadow-xl shadow-stone-200 flex items-center justify-center gap-2"
          >
            <Camera size={20} /> Mulai Scan
          </button>
          <button
            onClick={onViewCollection}
            className="w-full sm:w-auto bg-white text-stone-700 border border-stone-200 px-8 py-4 rounded-full font-bold text-lg hover:bg-stone-50 hover:border-stone-300 transition-all flex items-center justify-center gap-2"
          >
            <Book size={20} /> Lihat Koleksi
          </button>
        </div>
      </div>

      {/* Feature Highlights */}
      <div className="features-grid">
        {[
          { icon: <Search className="text-blue-600" />, title: "Deteksi AI", desc: "Akurasi tinggi dalam mengenali spesies." },
          { icon: <Info className="text-purple-600" />, title: "Info Lengkap", desc: "Habitat, toksisitas, dan fakta unik." },
          { icon: <MapPin className="text-red-600" />, title: "Pencatatan", desc: "Simpan lokasi dan tanggal temuanmu." }
        ].map((feature, i) => (
          <div key={i} className="feature-card">
            <div className="p-3 bg-white rounded-xl shadow-sm border border-stone-100">{feature.icon}</div>
            <div className="text-left">
              <h3 className="font-bold text-stone-900">{feature.title}</h3>
              <p className="text-sm text-stone-500 leading-snug">{feature.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}